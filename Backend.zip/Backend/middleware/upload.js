const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Ensure the upload directory exists
const createUploadDir = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// Define upload directories for different entities
const uploadDirs = {
  user: 'uploads/user',
  project: 'uploads/project',
  blog: 'uploads/blog' // Add blog upload directory
};

// Create all necessary upload directories
Object.values(uploadDirs).forEach(createUploadDir);

// Configure Multer storage with dynamic destination based on field name
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath;

    // Determine the upload directory based on the field name
    switch (file.fieldname) {
      case 'image': // For blog images
        uploadPath = uploadDirs.blog; // Store images in uploads/blog
        break;
      default:
        return cb(new Error('Invalid field name'), false);
    }

    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const extension = path.extname(file.originalname).toLowerCase();
    const originalName = path.basename(file.originalname, extension); // Get original file name without extension
    const filename = `${originalName}-${timestamp}${extension}`; // Use original name for clarity
    cb(null, filename);
  }
});

// File filter for image validation
const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png|gif/;
  const mimetype = allowedTypes.test(file.mimetype);
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());

  if (mimetype && extname) {
    cb(null, true);
  } else {
    cb(new Error('Only image files (jpeg, jpg, png, gif) are allowed!'), false);
  }
};

// Create multer instance with storage and file filter
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // Limit file size to 5MB
  }
});

module.exports = upload;
